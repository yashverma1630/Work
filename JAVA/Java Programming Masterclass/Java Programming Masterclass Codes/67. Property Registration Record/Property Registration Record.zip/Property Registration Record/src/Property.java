public record Property(String Propertyid, String Ownername, String Propertyaddress, String Dateofregistration, String Propertytype, String Choosegovid, String Govid, String Landarea, String Latitude, String Longitude,String originalsaleprice) {
}
